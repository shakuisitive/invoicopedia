import Dashboard from "./_components/Dashboard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

function Homepage() {
  return <Dashboard />;
}

export default Homepage;
