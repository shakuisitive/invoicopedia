export interface Customer {
  id: string;
  name: string;
  email: string;
  accountNumber: string;
}
